

function InsideOutsideBtn() {
  return (
    <div>
        <button id="insideOutsideBtn">condition button</button>
    </div>
  )
}

export default InsideOutsideBtn