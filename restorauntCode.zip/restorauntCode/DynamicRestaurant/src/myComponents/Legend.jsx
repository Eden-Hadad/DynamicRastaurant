
export default function Legend(){
    return(
        <>
        <h2 id="title">legend:</h2>
            <h3 id="available">O</h3>
            <h3 id="await">O</h3>
            <h3 id="taken">O</h3>


        </>
    )
}