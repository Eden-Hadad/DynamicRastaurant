import React from 'react'

function Title() {
  return (
    <div id="title">condition tite</div>
  )
}

export default Title