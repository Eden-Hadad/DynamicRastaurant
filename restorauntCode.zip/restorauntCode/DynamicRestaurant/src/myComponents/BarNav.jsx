export default function BarNavigate(){
//menu, contact us


    return(
        <>
        <div>
            <button> CONTACT US</button>
            <button> MENU-optional</button>

        </div>
        </>
    )

}