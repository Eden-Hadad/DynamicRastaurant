

function MenuDesign() {
  return (
    <>
   
<ul>
  <li>aquer table</li>{/*table with numbers 2/4/6/8+ input for the size of the table */}
  <li>bar</li>
</ul>  

    </>
  )
}

export default MenuDesign

