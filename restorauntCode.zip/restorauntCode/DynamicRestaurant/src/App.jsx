import './App.css'
import Form from './myComponents/Form'
import BarNavigate from './myComponents/BarNav'
import Legend from './myComponents/Legend'
import InsideOutsideBtn from './myComponents/InsideOutsideBtn'
import Title from './myComponents/Title'
function App() {
  return (
    <>
    <Title/>
    <InsideOutsideBtn/>
    <Legend/>
      <Form/>
    <BarNavigate/>
      
    </>
  )
}

export default App
